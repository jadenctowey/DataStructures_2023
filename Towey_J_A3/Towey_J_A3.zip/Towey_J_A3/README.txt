Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC350

Section: 03

Assignment: PA3: Do You See What I See?

Source Files: 
SpeakerView.h
SpeakerView.cpp
MonoStack.h
main.cpp
input.txt

References: 
- Chat GPT 
- https://stackoverflow.com/questions/14841941/c-save-txt-as-html-using-fstream 
- Sami Hammoud

To run:
	g++ -std=c++11 *.cpp -o main.exe
	./main.exe input.txt
