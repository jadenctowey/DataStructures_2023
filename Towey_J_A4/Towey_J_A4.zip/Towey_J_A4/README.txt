Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC350

Section: 03

Assignment: PA4: Genetic Palindrome?

Source Files: 
main.cpp
input.txt

References: 
- Chat GPT 
- https://www.w3schools.com/cpp/cpp_pointers.asp 
- https://cplusplus.com/doc/tutorial/pointers/ 
- Sami Hammoud 
- https://file.notion.so/f/s/880c3933-bb1e-42df-b9e3-4da8d64f1f94/C.pdf?id=16ca8ea2-8e09-42eb-840c-0d47554b9b07&table=block&spaceId=bb2414b6-dc5b-48c8-91d6-c4e0d4496389&expirationTimestamp=1698984000000&signature=aAsf_YcqsDg0QkeULVxAn19EjUo7L_RQHzkw0ggi9_g&downloadName=C%2B%2B.pdf 
- Owen Hickey 
- 

To run:
	g++ -std=c++11 *.cpp -o main.exe
	./main.exe input.txt