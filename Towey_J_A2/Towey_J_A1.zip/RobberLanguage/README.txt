Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC350

Section: 03

Assignment: PA1: Robber Language Translation 

Source Files: 
Model.cpp
Model.h
Translator.cpp
Translator.h
FileProcessor.cpp
FileProcessor.h 
main.cpp


References: 
https://www.w3schools.com/cpp/cpp_class_methods.asp 
https://www.geeksforgeeks.org/const-keyword-in-cpp/
https://www.programiz.com/cpp-programming/library-function/cctype/isalpha 
https://www.w3schools.com/cpp/cpp_user_input.asp 
https://www.geeksforgeeks.org/std-fstream-close-in-cpp/ 
https://www.w3schools.com/cpp/cpp_booleans.asp 
https://www.w3schools.com/cpp/cpp_for_loop.asp 
https://www.w3schools.com/cpp/cpp_syntax.asp 
https://www.w3schools.com/cpp/cpp_function_param.asp 
https://stackoverflow.com/questions/14841941/c-save-txt-as-html-using-fstream 

Sami Hammoud

To run:
	g++ -std=c++11 *.cpp -o main.exe
	./main.exe



	side note for me to compile: 
	g++ -std=c++11 *.cpp -o Translator.exe (for compiling Translator)
