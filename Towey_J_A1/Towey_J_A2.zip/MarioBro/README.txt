1) The following identifying information:
    a. Full name
        Jaden Towey
    b. Student ID
        2428763
    c. Chapman email
        towey@chapman.edu
    d. Course number and section
        CPSC 350-03
    e. Assignment or exercise number
        PA2: Not So Super Mario Bros.

2) A list of all source files submitted for the assignment
    Enemy.cpp
    Enemy.h 
    Level.cpp
    Level.h 
    main.cpp 
    Mario.cpp
    Mario.h 
    World.cpp 
    World.h

    sample input file:
    input.txt

3) A description of any known compile or runtime errors, code limitations, or deviations
from the assignment specification (if applicable)
Very rarely after restarting my computer or restarting vscode, I will sometimes notice that a few of the levels
have a red cube that says null.  Only have seen it twice before and not sure what could be causing it

4) A list of all references used to complete the assignment, including peers (if applicable)
    https://www.digitalocean.com/community/tutorials/random-number-generator-c-plus-plus
    Collaborated with Ashton Carter

5) Instructions for running the assignment. (Typically applicable in advanced courses using
build systems or third party libraries)
    g++ *.cpp 
    ./a.out input.txt gamelog.txt