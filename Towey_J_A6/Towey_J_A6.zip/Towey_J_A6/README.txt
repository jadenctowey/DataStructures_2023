Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC350

Section: 03

Assignment: PA6: Kruskal's

Source Files: 
WGraph.h
WGraph.cpp
WGraphMain.cpp
DblList.h 
ListNode.h 
Edge.cpp
Edge.h 
Processor.cpp
Processor.h 
input.txt 
main.cpp


References: 
- Sami Hammoud
- Ashton Carter
- Ronan McDermott
- Owen Hickey 
- W3 Schools
- Chat GPT 
- Stack overflow
- Were some errors between private and public variables 

To run:
	g++ -std=c++11 *.cpp -o main.exe
	./main.exe input.txt