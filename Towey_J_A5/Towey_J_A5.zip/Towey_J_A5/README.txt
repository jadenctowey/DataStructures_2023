Name: Jaden Towey

Student ID: 2420751

Chapman email: towey@chapman.edu

Course: CPSC350

Section: 03

Assignment: PA5: Lazy BST

Source Files: 
ListNode.h
DblList.h 
TreeNode.h 
LazyBST.h 
Student.cpp
Student.h
Teacher.cpp
Teacher.h
main.cpp
runLog.txt


References: 
- Chat GPT 
- Stack overflow
- Sami Hammoud
- Ashton Carter 
- My project does not run as it should. I can not figure out the teacher file no matter how hard I try

To run:
    g++ *.cpp
	g++ -std=c++11 *.cpp -o main.exe
